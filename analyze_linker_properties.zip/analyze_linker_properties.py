#/usr/bin/python3

'''
analyzes FASTA alignment for linker properties
by the incredible A.M. (andreas.moeglich@uni-bayreuth.de)
'''

ALIGNMENT = 'Aligned_Desired_hmmresults_PF00360_PHY_HK_no_dupes.fasta'
GAP_COUNT = 'GapCount_Aligned_Desired_hmmresults_PF00360_PHY_HK_no_dupes.txt'
CONSENSUS = 'Consensus_Aligned_Desired_hmmresults_PF00360_PHY_HK_no_dupes.txt'

LEFT, RIGHT = 774, 1365
COUNT_STATS = 'LinkerLength_Aligned_Desired_hmmresults_PF00360_PHY_HK_no_dupes.txt'
COUNT_MODULO = 'LinkerModulo_Aligned_Desired_hmmresults_PF00360_PHY_HK_no_dupes.txt'

# parse alignment
order, sequences, current = [], {}, ''
with open(ALIGNMENT, 'r') as readhandle:
  red = readhandle.readline()
  while red:
    red = red.strip()

    if(red.startswith('>')):
      order.append(red[1:])
      current = red[1:]
    elif(current):
      if(current in sequences):
        sequences[current] += red
      else:
        sequences[current] = red
      
    red = readhandle.readline()

# first do some statistics -- count gaps
length = len(sequences[order[0]])
columns = []
for j in range(length):
  columns.append([sequences[i][j] for i in sequences])

stats = []
for item in columns:
  stats.append(sum([0 if(i == '-') else 1 for i in item]))

with open(GAP_COUNT, 'w') as writehandle:
  for index, item in enumerate(stats):
    writehandle.write(str(index) + '\t' + str(item) + '\n')
    
# consensus sequence (simply take the aa that occurs most frequently)
with open(CONSENSUS, 'w') as writehandle:
  for pos in range(length):
    temp = {}
    for item in columns[pos]:
      if(item != '-'):
        if(item in temp):
          temp[item] += 1
        else:
          temp[item] = 1
    writehandle.write(str(pos) + '\t' + str((max(temp, key=temp.get))) + '\n')
    
# and now do some counting
linkers = {}
for item in sequences:
  red = sequences[item][LEFT:RIGHT]
  red = red.replace('-', '')
  ll = len(red)
  if(ll in linkers):
    linkers[ll] += 1
  else:
    linkers[ll] = 1

ll = list(linkers.keys())
ll_min, ll_max = min(ll), max(ll)

with open(COUNT_STATS, 'w') as writehandle:
  for ll in range(ll_min, ll_max + 1):
    if(ll in linkers):
      writehandle.write(str(ll) + '\t' + str(linkers[ll]) + '\n')
    else:
      writehandle.write(str(ll) + '\t0\n')

# and now calculate the modulo 7
modulo = [0] * 7
for ll in linkers:
  mod = ll % 7
  modulo[mod] += linkers[ll]

with open(COUNT_MODULO, 'w') as writehandle:
  for index, value in enumerate(modulo):
    writehandle.write(str(index) + '\t' + str(value) + '\n')
