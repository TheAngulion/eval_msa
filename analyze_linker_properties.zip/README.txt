Python script for evaluating a multiple sequence alignment
----------------------------------------------------------

by A.M. 2023 (andreas.moeglich@uni-bayreuth.de)

1. System requirements
- Python 3, tested on several versions from 3.6 - 3.12

2. Installation instructions
- copy to target directory
- place input alignment (.fasta file) in the same directory

3. Demo
- run the script (as is): analyze_linker_properties.py
- opens input multiple sequence alignment (MSA): Aligned_Desired_hmmresults_PF00360_PHY_HK_no_dupes.fasta
- outputs count of gaps in MSA: GapCount_Aligned_Desired_hmmresults_PF00360_PHY_HK_no_dupes.txt
- outputs consensus sequence of MSA: Consensus_Aligned_Desired_hmmresults_PF00360_PHY_HK_no_dupes.txt
- outputs linker length of MSA between positions specified in script (LEFT/RIGHT): LinkerLength_Aligned_Desired_hmmresults_PF00360_PHY_HK_no_dupes.txt
- outputs the modulo 7 of the above linker length: LinkerModulo_Aligned_Desired_hmmresults_PF00360_PHY_HK_no_dupes

4. Instructions for use
- generate multiple sequence alignment in fasta format, e.g., using Clustal, MUSCLE, or similar
- within the .py script, provide file name of MSA file as the variable ALIGNMENT
- set reference positions between which linker length is evaluated as the variables LEFT and RIGHT
- specify the output file names in the variables GAP_COUNT, CONSENSUS, COUNT_STATS, COUNT_MODULO
- run script from command line or out of IDE